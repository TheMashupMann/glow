﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class SceneManagerScript {

	public static void StartGame()
    {
        SceneManager.LoadScene("Game");
    }

    public static void ToMenu()
    {
        SceneManager.LoadScene("Main Menu");
    }

    public static void QuitGame()
    {
        Application.Quit();
    }
}
