﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDeath : MonoBehaviour {

    public GameObject playerUI, deathEffect;
    public PlayerMovement player;
    public AudioSource deathSound, respawnSound;
    public float waitTime;
    public Transform spawnPoint;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Die()
    {
        StartCoroutine(PlayerDie());
    }

    void Respawn()
    {
        respawnSound.Play();
        playerUI.SetActive(true);
        player.transform.position = spawnPoint.position;
        player.gameObject.SetActive(true);
    }

    IEnumerator PlayerDie()
    {
        GameObject effect = Instantiate(deathEffect, player.gameObject.transform);
        effect.transform.SetParent(null);
        player.gameObject.SetActive(false);
        playerUI.SetActive(false);
        deathSound.Play();
        yield return new WaitForSeconds(waitTime);
        Respawn();
    }

    public void SetSpawnPoint(Transform spawnPosition)
    {
        spawnPoint = spawnPosition;
    }
}
