﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerFade : MonoBehaviour {

    public enum States { Light, Fade };
    public States state;
    public Slider lightBar;
    public SpriteRenderer playerSprite;
    public PlayerDeath death;
    public Light playerLight;
    public bool inZone;
    public float fadeSpeed, minimumBrightness;
	
	// Update is called once per frame
	void Update ()
    {
        if (FindObjectOfType<PauseMenu>() != null)
        {
            if (FindObjectOfType<PauseMenu>().isPaused)
            {
                return;
            }
        }
        switch (state)
        {
            case States.Light:
                if (!inZone)
                {
                    state = States.Fade;
                    break;
                }
                if (playerSprite.color.r < 1)
                {
                    lightBar.value = lightBar.value + fadeSpeed*5 * Time.deltaTime;
                    playerLight.intensity = playerLight.intensity + fadeSpeed* 5 * Time.deltaTime;
                    playerSprite.color = new Color(playerSprite.color.r + fadeSpeed * 5 * Time.deltaTime, playerSprite.color.b + fadeSpeed * 5 * Time.deltaTime, playerSprite.color.g + fadeSpeed * 5 * Time.deltaTime, playerSprite.color.a);
                }
                else
                {
                    lightBar.value = lightBar.maxValue;
                    playerLight.intensity = 1;
                    playerSprite.color = new Color(1, 1, 1, playerSprite.color.a);

                }
                break;

            case States.Fade:
                if (inZone)
                {
                    state = States.Light;
                    break;
                }
                if (playerSprite.color.r > minimumBrightness)
                {
                    lightBar.value = lightBar.value - fadeSpeed * Time.deltaTime;
                    playerLight.intensity = playerLight.intensity - fadeSpeed * Time.deltaTime;
                    playerSprite.color = new Color(playerSprite.color.r - fadeSpeed * Time.deltaTime, playerSprite.color.b - fadeSpeed * Time.deltaTime, playerSprite.color.g - fadeSpeed * Time.deltaTime, playerSprite.color.a);
                }
                else
                {
                    death.Die();
                    ResetLight();
                }
                break;

            default:

                break;
        }
	}

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag == "LightBox")
        {
            inZone = true;
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "LightBox")
        {
            inZone = false;
        }
    }

    void ResetLight()
    {
        state = States.Light;
        lightBar.value = lightBar.maxValue;
        playerLight.intensity = 1;
        playerSprite.color = new Color(1, 1, 1, playerSprite.color.a);
    }
}
