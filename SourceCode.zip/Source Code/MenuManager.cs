﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuManager : MonoBehaviour {

    public GameObject settingsPage, aboutPage;
    public AudioSource mouseOver, mouseClick;

    public void ShowSettings()
    {
        HideAbout();
        settingsPage.SetActive(true);
    }

    void HideSettings()
    {
        settingsPage.SetActive(false);
    }

    public void ShowAbout()
    {
        HideSettings();
        aboutPage.SetActive(true);
    }

    void HideAbout()
    {
        aboutPage.SetActive(false);
    }

    public void StartGame()
    {
        SceneManagerScript.StartGame();
    }

    public void QuitGame()
    {
        SceneManagerScript.QuitGame();
    }

	// Use this for initialization
	void Start () {
        HideSettings();
        HideAbout();
	}

    public void PlayMouseOver()
    {
        mouseOver.Play();
    }

    public void PlayMouseClick()
    {
        mouseClick.Play();
    }
}
