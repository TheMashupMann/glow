﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PauseMenu : MonoBehaviour {

    public GameObject pauseMenu, inGameUI, optionsMenu, endScreen, endText;
    public KeyCode pauseButton;
    public bool isPaused, isCinematic;
    public enum States { Paused, inGame };
    public States state;
    public float fadeOutSpeed, fadeInSpeed;
    public AudioSource mouseOver, mouseClick;

    private void Start()
    {
        StartCoroutine(StartGame());
    }

    // Update is called once per frame
    void Update () {
        if (isCinematic)
        {
            return;
        }
		switch(state)
        {
            case States.Paused:
                if (Input.GetKeyDown(pauseButton))
                {
                    Resume();
                }
                Time.timeScale = 0;
                break;
            case States.inGame:
                if (Input.GetKeyDown(pauseButton))
                {
                    Pause();
                }
                Time.timeScale = 1;
                break;
        }
	}

    public void ToOptions()
    {
        pauseMenu.SetActive(false);
        optionsMenu.SetActive(true);
    }

    public void ExitOptions()
    {
        pauseMenu.SetActive(true);
        optionsMenu.SetActive(false);
    }

    public void Pause ()
    {
        state = States.Paused;
        isPaused = true;
        pauseMenu.SetActive(true);
        inGameUI.SetActive(false);
    }
    
    public void Resume()
    {
        state = States.inGame;
        isPaused = false;
        pauseMenu.SetActive(false);
        inGameUI.SetActive(true);
    }

    public void ToMenu()
    {
        SceneManagerScript.ToMenu();
    }

    public IEnumerator StartGame()
    {
        state = States.Paused;
        Time.timeScale = 0;
        isPaused = true;
        isCinematic = true;
        endScreen.SetActive(true);
        Image i = endScreen.GetComponent<Image>();
        i.color = new Color(i.color.r, i.color.g, i.color.b, 0);
        yield return StartCoroutine(FadeOut(endScreen, "Image"));
        Debug.Log("Done");
        isCinematic = false;
        endScreen.SetActive(false);
        Resume();
    }

    public void EndGame()
    {
        isPaused = true;
        isCinematic = true;
        StartCoroutine(RunEndGame());
    }

    IEnumerator RunEndGame()
    {
        endScreen.SetActive(true);
        state = States.Paused;
        yield return StartCoroutine(FadeIn(endScreen, "Image"));
        yield return new WaitForSeconds(1);
        yield return StartCoroutine(FadeIn(endText, "Text"));
        yield return new WaitForSeconds(3);
        yield return StartCoroutine(FadeOut(endText, "Text"));
        SceneManagerScript.ToMenu();
    }

    IEnumerator FadeOut(GameObject o, string IsImageOrText)
    {
        if (IsImageOrText == "Image")
        {
            o.GetComponent<Image>().color = new Color(o.GetComponent<Image>().color.r, o.GetComponent<Image>().color.g, o.GetComponent<Image>().color.b, 1);
            while (o.GetComponent<Image>().color.a > 0)
            {
                StartCoroutine(Fade(false, o, IsImageOrText));
                yield return null;
            }
        }
        else if (IsImageOrText == "Text")
        {
            o.GetComponent<Text>().color = new Color(o.GetComponent<Text>().color.r, o.GetComponent<Text>().color.g, o.GetComponent<Text>().color.b, 1);
            while (o.GetComponent<Text>().color.a > 0)
            {
                StartCoroutine(Fade(false, o, IsImageOrText));
                yield return null;
            }
        }
        yield break;
    }

    IEnumerator FadeIn(GameObject o, string IsImageOrText)
    {
        if (IsImageOrText == "Image")
        {
            o.GetComponent<Image>().color = new Color(o.GetComponent<Image>().color.r, o.GetComponent<Image>().color.g, o.GetComponent<Image>().color.b, 0);
            while (o.GetComponent<Image>().color.a < 1)
            {
                StartCoroutine(Fade(true, o, IsImageOrText));
                yield return null;
            }
        }
        else if (IsImageOrText == "Text")
        {
            o.GetComponent<Text>().color = new Color(o.GetComponent<Text>().color.r, o.GetComponent<Text>().color.g, o.GetComponent<Text>().color.b, 0);
            while (o.GetComponent<Text>().color.a < 1)
            {
                StartCoroutine(Fade(true, o, IsImageOrText));
                yield return null;
            }
        }
        yield break;
    }

    IEnumerator Fade(bool InOrOut, GameObject o, string IsImageOrText)
    {
        if (IsImageOrText == "Image")
        {
            Image i = o.GetComponent<Image>();
            if (InOrOut)
            {
                i.color = new Color(i.color.r, i.color.g, i.color.b, i.color.a + fadeInSpeed);
            }
            else
            {
                i.color = new Color(i.color.r, i.color.g, i.color.b, i.color.a - fadeOutSpeed);
            }
        }
        else if (IsImageOrText == "Text")
        {
            Text i = o.GetComponent<Text>();
            if (InOrOut)
            {
                i.color = new Color(i.color.r, i.color.g, i.color.b, i.color.a + fadeInSpeed);
            }
            else
            {
                i.color = new Color(i.color.r, i.color.g, i.color.b, i.color.a - fadeOutSpeed);
            }
        }
        yield return null;
    }

    public void PlayMouseOver()
    {
        mouseOver.Play();
    }

    public void PlayMouseClick()
    {
        mouseClick.Play();
    }
}
