﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;

public class OptionsMenu : MonoBehaviour {

    public AudioMixer audioMixer;
    public Dropdown resolutionDropdown, qualityDropdown;
    public Slider mainSlider, musicSlider, soundSlider;
    public Toggle fullscreen;
    Resolution[] resolutions;

	// Use this for initialization
	void Start () {
        resolutions = Screen.resolutions;
        resolutionDropdown.ClearOptions();
        List<string> options = new List<string>();
        int currentResolutionIndex = 0;
        for (int i=0; i<resolutions.Length; i++)
        {
            string option = resolutions[i].width + " x " + resolutions[i].height;
            options.Add(option);
            if (resolutions[i].width == Screen.currentResolution.width && resolutions[i].height == Screen.currentResolution.height)
            {
                currentResolutionIndex = i;
            }
        }
        resolutionDropdown.AddOptions(options);
        resolutionDropdown.value = currentResolutionIndex;
        resolutionDropdown.RefreshShownValue();

        qualityDropdown.value = QualitySettings.GetQualityLevel();
        qualityDropdown.RefreshShownValue();

        float mainV = 0f;
        audioMixer.GetFloat("masterVolume", out mainV);
        mainSlider.value = mainV;

        float soundV = 0f;
        audioMixer.GetFloat("soundVolume", out soundV);
        soundSlider.value = soundV;

        float musicV = 0f;
        audioMixer.GetFloat("musicVolume", out musicV);
        musicSlider.value = musicV;

        fullscreen.isOn = Screen.fullScreen;

	}

    public void SetQuality(int qualityIndex)
    {
        QualitySettings.SetQualityLevel(qualityIndex);
    }

    public void ToggleFullscreen(bool isFullScreen)
    {
        Screen.fullScreen = isFullScreen;
    }

    public void ChangeResolution(int resolutionIndex)
    {
        Resolution resolution = resolutions[resolutionIndex];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);
    }

    public void ChangeMainVolume(float volume)
    {
        audioMixer.SetFloat("masterVolume", volume);
    }

    public void ChangeMusicVolume(float volume)
    {
        audioMixer.SetFloat("musicVolume", volume);
    }

    public void ChangeSoundVolume(float volume)
    {
        audioMixer.SetFloat("soundVolume", volume);
    }
}
