﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {

    public KeyCode upButton, leftButton, rightButton, downButton;
    public Rigidbody2D body;
    public float moveSpeed, jumpSpeed, initialJumpTime, jumpTime;
    public bool Grounded, delayedGrounded, onWall, onLeftWall, onRightWall, hitCeiling, hasJumped;
    public Animator anim;
    public Transform groundCheck, leftWallCheck, rightWallCheck, ceilingCheck;
    public LayerMask whatIsGround;
    public GameObject groundEffect;
    public AudioSource[] soundPlayer = new AudioSource[2];

    private void Start()
    {
        jumpTime = initialJumpTime;
        delayedGrounded = Grounded;
    }

    // Update is called once per frame
    void FixedUpdate() {

        Grounded = Physics2D.OverlapCircle(groundCheck.position, 0.05f, whatIsGround);
        hitCeiling = Physics2D.OverlapCircle(ceilingCheck.position, 0.05f, whatIsGround);
        onLeftWall = Physics2D.OverlapCircle(leftWallCheck.position, 0.05f, whatIsGround);
        onRightWall = Physics2D.OverlapCircle(rightWallCheck.position, 0.05f, whatIsGround);

        anim.SetBool("Grounded", Grounded);
        anim.SetBool("OnLeftWall", onLeftWall && onWall);
        anim.SetBool("OnRightWall", onRightWall && onWall);

        anim.SetFloat("xSpeed", body.velocity.x);
        anim.SetFloat("ySpeed", body.velocity.y);

        if (FindObjectOfType<PauseMenu>() != null)
        {
            if (FindObjectOfType<PauseMenu>().isPaused)
            {
                return;
            }
        }

        if (!onWall)
        {
            if (Grounded)
            {
                if (!delayedGrounded)
                {
                    Instantiate(groundEffect, groundCheck.position, Quaternion.identity);
                    soundPlayer[1].Play();
                    delayedGrounded = true;
                }
                if (Input.GetKeyDown(upButton))
                {
                    Jump();
                    soundPlayer[0].Play();
                }
                Land();
            }
            else
            {
                delayedGrounded = false;
            }

            if (hitCeiling)
            {
                hasJumped = true;
            }
            else { Fall(); }
            if (!Grounded && Input.GetKey(upButton) && jumpTime > 0 && !hasJumped)
            {
                Jump();
            }

            if (onLeftWall || onRightWall)
            {
                if (onLeftWall && body.velocity.x < 2 && !Input.GetKey(rightButton))
                {
                    StickToWall();
                }
                else if (onRightWall && body.velocity.x > -2 && !Input.GetKey(leftButton))
                {
                    StickToWall();
                }
            }
            if (Input.GetKeyUp(upButton)) { hasJumped = true; }
            if (Input.GetKey(leftButton)) { MoveLeft(); }
            if (Input.GetKey(rightButton)) { MoveRight(); }

            if (!onLeftWall && !onRightWall)
            {
                body.isKinematic = false;
            }
        }
        else if (onWall)
        {
            body.velocity = Vector2.zero;
            if (!onLeftWall && !onRightWall)
            {
                JumpOffWall();
            }
            else if (onLeftWall)
            {
                if (Grounded)
                {
                    body.position = new Vector2(body.position.x + 0.2f, body.position.y);
                    UnstickToWall();
                }
                else
                {
                    body.isKinematic = true;
                    if (Input.GetKey(rightButton))
                    {
                        anim.SetTrigger("moveRight");
                        anim.ResetTrigger("moveLeft");
                        if (Input.GetKey(upButton))
                        {
                            JumpOffWall();
                            soundPlayer[0].Play();
                            body.velocity = new Vector2(moveSpeed* 1.5f * Time.deltaTime, jumpSpeed * Time.deltaTime);
                        }
                        else
                        {
                            UnstickToWall();
                            body.velocity = new Vector2(moveSpeed * Time.deltaTime / 2, body.velocity.y);
                        }
                    }
                    else if (Input.GetKey(downButton))
                    {
                        body.isKinematic = false;
                        body.velocity = new Vector2(body.velocity.x, -100 * Time.deltaTime);
                    }
                }
            }

            else if (onRightWall)
            {
                if (Grounded)
                {
                    body.position = new Vector2(body.position.x - 0.2f, body.position.y);
                    UnstickToWall();
                }
                else
                {
                    body.isKinematic = true;
                    if (Input.GetKey(leftButton))
                    {
                        anim.SetTrigger("moveLeft");
                        anim.ResetTrigger("moveRight");
                        if (Input.GetKey(upButton))
                        {
                            JumpOffWall();
                            soundPlayer[0].Play();
                            body.velocity = new Vector2(-moveSpeed* 1.5f * Time.deltaTime, jumpSpeed * 2 * Time.deltaTime);
                        }
                        else
                        {
                            UnstickToWall();
                            body.velocity = new Vector2(-moveSpeed * Time.deltaTime / 5, body.velocity.y);
                        }
                    }
                    else if (Input.GetKey(downButton))
                    {
                        body.isKinematic = false;
                        body.velocity = new Vector2(body.velocity.x, -100 * Time.deltaTime);
                    }
                }
            }
        }
	}

    public void Land()
    {
        Grounded = true;
        hasJumped = false;
        jumpTime = initialJumpTime;
    }

    public void Jump()
    {
        jumpTime -= 0.1f * Time.deltaTime;
        body.velocity = new Vector2(body.velocity.x, jumpSpeed);
    }

    public void Fall() { body.velocity = new Vector2(body.velocity.x, body.velocity.y - 1); }

    public void MoveLeft()
    {
        body.velocity = new Vector2(-moveSpeed * Time.deltaTime, body.velocity.y);
        anim.SetTrigger("moveLeft");
        anim.ResetTrigger("moveRight");
    }

    public void MoveRight()
    {
        body.velocity = new Vector2(moveSpeed * Time.deltaTime, body.velocity.y);
        anim.ResetTrigger("moveLeft");
        anim.SetTrigger("moveRight");
    }

    public void StickToWall()
    {
        hasJumped = false;
        jumpTime = initialJumpTime;
        onWall = true;
        body.velocity = Vector2.zero;
        soundPlayer[1].Play();
    }
    public void UnstickToWall()
    {
        hasJumped = true;
        jumpTime = 0;
        JumpOffWall();
    }

    public void JumpOffWall()
    {
        body.isKinematic = false;
        onWall = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Danger")
        {
            FindObjectOfType<PlayerDeath>().Die();
        }
    }
}
