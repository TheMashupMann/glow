﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuManager : MonoBehaviour {

    public GameObject settingsPage, aboutPage, controlsPage;
    public AudioSource mouseOver, mouseClick;

    public void ShowSettings()
    {
        HideAbout();
        HideControls();
        settingsPage.SetActive(true);
    }

    void HideSettings()
    {
        settingsPage.SetActive(false);
    }

    public void ShowAbout()
    {
        HideSettings();
        HideControls();
        aboutPage.SetActive(true);
    }

    void HideAbout()
    {
        aboutPage.SetActive(false);
    }

    public void ShowControls()
    {
        HideSettings();
        HideAbout();
        controlsPage.SetActive(true);
    }

    void HideControls()
    {
        controlsPage.SetActive(false);
    }

    public void StartGame()
    {
        SceneManagerScript.StartGame();
    }

    public void QuitGame()
    {
        SceneManagerScript.QuitGame();
    }

	// Use this for initialization
	void Start () {
        HideSettings();
        HideAbout();
        HideControls();
	}

    public void PlayMouseOver()
    {
        mouseOver.Play();
    }

    public void PlayMouseClick()
    {
        mouseClick.Play();
    }
}
