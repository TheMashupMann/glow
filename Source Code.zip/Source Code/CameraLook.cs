﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraLook : MonoBehaviour {

    public float moveSpeed;
    public GameObject cam;
    public Transform centerPoint, leftPoint, upPoint, rightPoint, downPoint;
    public KeyCode leftButton, upButton, rightButton, downButton;

    public void Update()
    {
        if (!Input.GetKey(leftButton) && !Input.GetKey(upButton) && !Input.GetKey(rightButton) && !Input.GetKey(downButton))
        {
            cam.transform.position = Vector3.Slerp(cam.transform.position, centerPoint.transform.position, moveSpeed);
        }
        else if (Input.GetKey(leftButton))
        {
            cam.transform.position = Vector3.Slerp(cam.transform.position, leftPoint.transform.position, moveSpeed);
        }
        else if (Input.GetKey(upButton))
        {
            cam.transform.position = Vector3.Slerp(cam.transform.position, upPoint.transform.position, moveSpeed);
        }
        else if (Input.GetKey(rightButton))
        {
            cam.transform.position = Vector3.Slerp(cam.transform.position, rightPoint.transform.position, moveSpeed);
        }
        else if (Input.GetKey(downButton))
        {
            cam.transform.position = Vector3.Slerp (cam.transform.position, downPoint.transform.position, moveSpeed);
        }
    }
}
