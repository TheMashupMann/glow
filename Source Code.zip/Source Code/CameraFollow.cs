﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {

    public PlayerMovement player;
    public float followSpeed;

    private void Update()
    {
        transform.position = Vector2.Lerp(transform.position, player.transform.position, followSpeed);
        //transform.position = new Vector2(transform.position.x, 0);
    }
}
